﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_7
{
    public partial class Form1 : Form
    {

        private Rectangle rect = null;
        private Circle circ = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonRectCalculate_Click(object sender, EventArgs e)
        {
            labelRectArea.Text = rect.Area().ToString();
        }

        private void buttonRectAssignAndDisplay_Click(object sender, EventArgs e)
        {
            rect = new Rectangle(textRectID.Text, "My Rectangle", Convert.ToDouble(textRectWidth.Text), Convert.ToDouble(textRectHeight.Text));
            labelRectDisplay.Text = rect.ToString();
        }

        private void buttonCircleAssignAndDisplay_Click(object sender, EventArgs e)
        {
            circ = new Circle(textCircleID.Text, "My Circle", Convert.ToDouble(textRadius.Text));
            labelCircleDisplay.Text = circ.ToString();
        }

        private void buttonCircleCalculate_Click(object sender, EventArgs e)
        {

        }
    }
}
