﻿
namespace Lab10_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonCircleCalculate = new System.Windows.Forms.Button();
            this.buttonCircleAssignAndDisplay = new System.Windows.Forms.Button();
            this.labelCircleDisplay = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelCircleArea = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textRadius = new System.Windows.Forms.TextBox();
            this.textCircleID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonRectCalculate = new System.Windows.Forms.Button();
            this.buttonRectAssignAndDisplay = new System.Windows.Forms.Button();
            this.labelRectDisplay = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelRectArea = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textRectHeight = new System.Windows.Forms.TextBox();
            this.textRectWidth = new System.Windows.Forms.TextBox();
            this.textRectID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonCircleCalculate);
            this.groupBox2.Controls.Add(this.buttonCircleAssignAndDisplay);
            this.groupBox2.Controls.Add(this.labelCircleDisplay);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.labelCircleArea);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textRadius);
            this.groupBox2.Controls.Add(this.textCircleID);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(51, 448);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox2.Size = new System.Drawing.Size(1111, 303);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Circle";
            // 
            // buttonCircleCalculate
            // 
            this.buttonCircleCalculate.Location = new System.Drawing.Point(456, 205);
            this.buttonCircleCalculate.Margin = new System.Windows.Forms.Padding(5);
            this.buttonCircleCalculate.Name = "buttonCircleCalculate";
            this.buttonCircleCalculate.Size = new System.Drawing.Size(257, 47);
            this.buttonCircleCalculate.TabIndex = 26;
            this.buttonCircleCalculate.Text = "Calculate Area";
            this.buttonCircleCalculate.UseVisualStyleBackColor = true;
            this.buttonCircleCalculate.Click += new System.EventHandler(this.buttonCircleCalculate_Click);
            // 
            // buttonCircleAssignAndDisplay
            // 
            this.buttonCircleAssignAndDisplay.Location = new System.Drawing.Point(107, 205);
            this.buttonCircleAssignAndDisplay.Margin = new System.Windows.Forms.Padding(5);
            this.buttonCircleAssignAndDisplay.Name = "buttonCircleAssignAndDisplay";
            this.buttonCircleAssignAndDisplay.Size = new System.Drawing.Size(274, 47);
            this.buttonCircleAssignAndDisplay.TabIndex = 25;
            this.buttonCircleAssignAndDisplay.Text = "Assign and Display";
            this.buttonCircleAssignAndDisplay.UseVisualStyleBackColor = true;
            this.buttonCircleAssignAndDisplay.Click += new System.EventHandler(this.buttonCircleAssignAndDisplay_Click);
            // 
            // labelCircleDisplay
            // 
            this.labelCircleDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelCircleDisplay.Location = new System.Drawing.Point(536, 51);
            this.labelCircleDisplay.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelCircleDisplay.Name = "labelCircleDisplay";
            this.labelCircleDisplay.Size = new System.Drawing.Size(490, 44);
            this.labelCircleDisplay.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(413, 51);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 29);
            this.label7.TabIndex = 22;
            this.label7.Text = "Display:";
            // 
            // labelCircleArea
            // 
            this.labelCircleArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelCircleArea.Location = new System.Drawing.Point(536, 129);
            this.labelCircleArea.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelCircleArea.Name = "labelCircleArea";
            this.labelCircleArea.Size = new System.Drawing.Size(490, 44);
            this.labelCircleArea.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(442, 144);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 29);
            this.label9.TabIndex = 24;
            this.label9.Text = "Area:";
            // 
            // textRadius
            // 
            this.textRadius.Location = new System.Drawing.Point(156, 112);
            this.textRadius.Margin = new System.Windows.Forms.Padding(5);
            this.textRadius.Name = "textRadius";
            this.textRadius.Size = new System.Drawing.Size(223, 34);
            this.textRadius.TabIndex = 18;
            this.textRadius.Text = "2.25";
            // 
            // textCircleID
            // 
            this.textCircleID.Location = new System.Drawing.Point(156, 51);
            this.textCircleID.Margin = new System.Windows.Forms.Padding(5);
            this.textCircleID.Name = "textCircleID";
            this.textCircleID.Size = new System.Drawing.Size(223, 34);
            this.textCircleID.TabIndex = 15;
            this.textCircleID.Text = "C001";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 115);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 29);
            this.label11.TabIndex = 19;
            this.label11.Text = "Radius:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(89, 60);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 29);
            this.label12.TabIndex = 17;
            this.label12.Text = "ID:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonRectCalculate);
            this.groupBox1.Controls.Add(this.buttonRectAssignAndDisplay);
            this.groupBox1.Controls.Add(this.labelRectDisplay);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.labelRectArea);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textRectHeight);
            this.groupBox1.Controls.Add(this.textRectWidth);
            this.groupBox1.Controls.Add(this.textRectID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(51, 69);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox1.Size = new System.Drawing.Size(1060, 350);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rectangle";
            // 
            // buttonRectCalculate
            // 
            this.buttonRectCalculate.Location = new System.Drawing.Point(447, 238);
            this.buttonRectCalculate.Margin = new System.Windows.Forms.Padding(5);
            this.buttonRectCalculate.Name = "buttonRectCalculate";
            this.buttonRectCalculate.Size = new System.Drawing.Size(266, 43);
            this.buttonRectCalculate.TabIndex = 14;
            this.buttonRectCalculate.Text = "Calculate Area";
            this.buttonRectCalculate.UseVisualStyleBackColor = true;
            this.buttonRectCalculate.Click += new System.EventHandler(this.buttonRectCalculate_Click);
            // 
            // buttonRectAssignAndDisplay
            // 
            this.buttonRectAssignAndDisplay.Location = new System.Drawing.Point(107, 238);
            this.buttonRectAssignAndDisplay.Margin = new System.Windows.Forms.Padding(5);
            this.buttonRectAssignAndDisplay.Name = "buttonRectAssignAndDisplay";
            this.buttonRectAssignAndDisplay.Size = new System.Drawing.Size(272, 43);
            this.buttonRectAssignAndDisplay.TabIndex = 13;
            this.buttonRectAssignAndDisplay.Text = "Assign and Display";
            this.buttonRectAssignAndDisplay.UseVisualStyleBackColor = true;
            this.buttonRectAssignAndDisplay.Click += new System.EventHandler(this.buttonRectAssignAndDisplay_Click);
            // 
            // labelRectDisplay
            // 
            this.labelRectDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRectDisplay.Location = new System.Drawing.Point(536, 48);
            this.labelRectDisplay.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRectDisplay.Name = "labelRectDisplay";
            this.labelRectDisplay.Size = new System.Drawing.Size(490, 44);
            this.labelRectDisplay.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(413, 61);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Display:";
            // 
            // labelRectArea
            // 
            this.labelRectArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRectArea.Location = new System.Drawing.Point(536, 109);
            this.labelRectArea.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRectArea.Name = "labelRectArea";
            this.labelRectArea.Size = new System.Drawing.Size(490, 44);
            this.labelRectArea.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(442, 124);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 29);
            this.label4.TabIndex = 12;
            this.label4.Text = "Area:";
            // 
            // textRectHeight
            // 
            this.textRectHeight.Location = new System.Drawing.Point(156, 174);
            this.textRectHeight.Margin = new System.Windows.Forms.Padding(5);
            this.textRectHeight.Name = "textRectHeight";
            this.textRectHeight.Size = new System.Drawing.Size(223, 34);
            this.textRectHeight.TabIndex = 8;
            this.textRectHeight.Text = "4.5";
            // 
            // textRectWidth
            // 
            this.textRectWidth.Location = new System.Drawing.Point(156, 119);
            this.textRectWidth.Margin = new System.Windows.Forms.Padding(5);
            this.textRectWidth.Name = "textRectWidth";
            this.textRectWidth.Size = new System.Drawing.Size(223, 34);
            this.textRectWidth.TabIndex = 6;
            this.textRectWidth.Text = "3.5";
            // 
            // textRectID
            // 
            this.textRectID.Location = new System.Drawing.Point(156, 58);
            this.textRectID.Margin = new System.Windows.Forms.Padding(5);
            this.textRectID.Name = "textRectID";
            this.textRectID.Size = new System.Drawing.Size(223, 34);
            this.textRectID.TabIndex = 3;
            this.textRectID.Text = "R001";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 177);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 29);
            this.label3.TabIndex = 4;
            this.label3.Text = "Height:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 122);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 29);
            this.label2.TabIndex = 7;
            this.label2.Text = "Width:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(89, 61);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 857);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Area Calculation";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonCircleCalculate;
        private System.Windows.Forms.Button buttonCircleAssignAndDisplay;
        private System.Windows.Forms.Label labelCircleDisplay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelCircleArea;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textRadius;
        private System.Windows.Forms.TextBox textCircleID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRectCalculate;
        private System.Windows.Forms.Button buttonRectAssignAndDisplay;
        private System.Windows.Forms.Label labelRectDisplay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelRectArea;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textRectHeight;
        private System.Windows.Forms.TextBox textRectWidth;
        private System.Windows.Forms.TextBox textRectID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

