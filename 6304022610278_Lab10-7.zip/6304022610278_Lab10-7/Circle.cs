﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_7
{
    class Circle : Shape
    {
        private double _dRadius;
        public double Radius { get; set; }
        public Circle() : base()
        {
            Radius = 1;
        }
        public Circle(string sID, string sName, double dRadius) : base(sID, sName)
        {
            Radius = dRadius;
        }
        public override double Area()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
        public override string ToString()
        {
            return $"{ID} ({Name}) <{Radius}>";
        }
    }
}
