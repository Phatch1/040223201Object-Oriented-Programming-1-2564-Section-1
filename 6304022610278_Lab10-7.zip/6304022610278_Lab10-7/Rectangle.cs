﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_7
{
    class Rectangle : Shape
    {
        private double _dWidth;
        private double _dheight;
        public double Width { get; set; }
        public double Height { get; set; }
        public Rectangle() : base()
        {
            Width = 1;
            Height = 1;
        }
        public Rectangle(string sID, string sName, double dWidth, double dHeight) : base(sID, sName)
        {
            ID = sID;
            Width = dWidth;
            Height = dHeight;
        }
        public override double Area()
        {
            return Width * Height;
        }
        public override string ToString()
        {
            return $"{ID} ({Name}) <{Width},{Height}>";
        }
    }
}
