﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework3_2
{
    public partial class Form1 : Form
    {
        private Rectangle rectangle = null;
        private Circle circle = null;
        private Triangle triangle = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonRectAssignAndDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                rectangle = new Rectangle(textRectID.Text, "My Rectangle", Convert.ToDouble(textRectWidth.Text), Convert.ToDouble(textRectHeight.Text));
                labelRectDisplay.Text = rectangle.ToString();
            }
            catch(ArgumentOutOfRangeException outOfRange)
            {
                MessageBox.Show(outOfRange.Message,"Out Of Range!",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch(FormatException formatException)
            {
                MessageBox.Show(formatException.Message, "Invalid Format", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonRectCalculate_Click(object sender, EventArgs e)
        {
            labelRectArea.Text = rectangle.Area().ToString("0.00");
            labelRectPerimeter.Text = rectangle.Perimeter().ToString("0.00");
        }

        private void buttonCircleAssignAndDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                circle = new Circle(textCircleID.Text, "My Circle", Convert.ToDouble(textRadius.Text));
                labelCircleDisplay.Text = circle.ToString();
            }
            catch (ArgumentOutOfRangeException outOfRange)
            {
                MessageBox.Show(outOfRange.Message, "Out Of Range!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FormatException formatException)
            {
                MessageBox.Show(formatException.Message, "Invalid Format", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonCircleCalculate_Click(object sender, EventArgs e)
        {
            labelCircleArea.Text = circle.Area().ToString("0.00");
            labelCirclePerimeter.Text = circle.Perimeter().ToString("0.00");
        }

        private void buttonTriAssignNDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                triangle = new Triangle(textTriID.Text, "My Triangle", Convert.ToDouble(textTriBase.Text), Convert.ToDouble(textTriHeight.Text));
                labelTriDisplay.Text = triangle.ToString();
            }
            catch (ArgumentOutOfRangeException outOfRange)
            {
                MessageBox.Show(outOfRange.Message, "Out Of Range!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FormatException formatException)
            {
                MessageBox.Show(formatException.Message, "Invalid Format", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonCalTriArea_Click(object sender, EventArgs e)
        {
            labelTriArea.Text = triangle.Area().ToString("0.00");
            labelTriPerimeter.Text = triangle.Perimeter().ToString("0.00");
        }
    }
}
