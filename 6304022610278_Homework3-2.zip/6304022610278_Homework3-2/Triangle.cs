﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3_2
{
    class Triangle : Shape
    {
        private double _dBase;
        private double _dHeight;

        public double Base 
        {
            get { return _dBase; }
            set{_dBase = (value < 0) ? throw new ArgumentOutOfRangeException("Value cannot be a negative number") : value;}
        }
        public double Height 
        {
            get { return _dHeight; }
            set
            {
                //if (value < 0)
                //{
                //    throw new ArgumentOutOfRangeException("Value cannot be a negative number");
                //}
                //else
                //{
                //    _dHeight = value;
                //}
                _dHeight = (value < 0) ? throw new ArgumentOutOfRangeException("Value cannot be a negative number") : value;
            }
        }

        public Triangle() { }
        public Triangle(string sID,string sName,double dBase,double dHeight) :base(sID,sName)
        {
            Base = dBase;
            Height = dHeight;
        }
        public override double Area()
        {
            return  Base * Height *0.5;
        }
        public override string ToString()
        {
            return $"{ID} ({Name}) <{Base},{Height}>";
        }
        public override double Perimeter()
        {
            return Base + Height + (Math.Sqrt(Math.Pow(Height, 2) + Math.Pow(Base, 2)));
        }
    }
}
