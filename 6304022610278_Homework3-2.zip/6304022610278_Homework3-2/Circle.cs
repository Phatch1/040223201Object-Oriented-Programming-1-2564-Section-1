﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3_2
{
    class Circle : Shape
    {
        private double _dRadius;
        public double Radius 
        {
            get {return _dRadius;}
            set {_dRadius = (value < 0) ? throw new ArgumentOutOfRangeException("Value cannot be a negative number") : value;} 
        }
        public Circle() : base()
        {
            Radius = 1;
        }
        public Circle(string sID, string sName, double dRadius) : base(sID, sName)
        {
            Radius = dRadius;
        }
        public override double Area()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
        public override string ToString()
        {
            return $"{ID} ({Name}) <{Radius}>";
        }
        public override double Perimeter()
        {
            return 2 * Math.PI * Radius;
        }
    }
}
