﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3_2
{
    class Rectangle : Shape
    {
        private double _dWidth;
        private double _dHeight;
        public double Width 
        {
            get { return _dWidth; }
            set
            {
              
                _dWidth = (value < 0) ? throw new ArgumentOutOfRangeException("Value cannot be a negative number") : value;
            }
        }
        public double Height 
        {
            get { return _dHeight; }
            set {_dHeight = (value < 0) ? throw new ArgumentOutOfRangeException("Value cannot be a negative number") : value;}
        }
        public Rectangle() : base()
        {
            Width = 1;
            Height = 1;
        }
        public Rectangle(string sID, string sName, double dWidth, double dHeight) : base(sID, sName)
        {
            ID = sID;
            Width = dWidth;
            Height = dHeight;
        }
        public override double Area() => Width * Height;

        public override string ToString() => $"{ID} ({Name}) <{Width},{Height}>";

        public override double Perimeter() => 2 * (Width + Height);
    }
}
