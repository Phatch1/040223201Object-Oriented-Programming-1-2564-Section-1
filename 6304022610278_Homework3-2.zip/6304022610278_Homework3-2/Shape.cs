﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3_2
{
    abstract class Shape
    {
        private string _sID;
        private string _sName;
        public string ID { get; set; }
        public string Name { get; }
        public Shape()
        {
            Name = "My Shape";
            ID = "R001";
        }
        public Shape(string sID, string sName)
        {
            ID = sID;
            Name = sName;
        }
        public abstract double Area();
        public abstract double Perimeter();
    }
}

