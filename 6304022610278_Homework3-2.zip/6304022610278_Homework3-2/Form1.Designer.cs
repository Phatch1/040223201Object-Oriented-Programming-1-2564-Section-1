﻿
namespace Homework3_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelCirclePerimeter = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.buttonCircleCalculate = new System.Windows.Forms.Button();
            this.buttonCircleAssignAndDisplay = new System.Windows.Forms.Button();
            this.labelCircleDisplay = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelCircleArea = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textRadius = new System.Windows.Forms.TextBox();
            this.textCircleID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelRectPerimeter = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.buttonRectCalculate = new System.Windows.Forms.Button();
            this.buttonRectAssignAndDisplay = new System.Windows.Forms.Button();
            this.labelRectDisplay = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelRectArea = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textRectHeight = new System.Windows.Forms.TextBox();
            this.textRectWidth = new System.Windows.Forms.TextBox();
            this.textRectID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonCalTriArea = new System.Windows.Forms.Button();
            this.buttonTriAssignNDisplay = new System.Windows.Forms.Button();
            this.labelTriDisplay = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelTriPerimeter = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelTriArea = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textTriHeight = new System.Windows.Forms.TextBox();
            this.textTriBase = new System.Windows.Forms.TextBox();
            this.textTriID = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelCirclePerimeter);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.buttonCircleCalculate);
            this.groupBox2.Controls.Add(this.buttonCircleAssignAndDisplay);
            this.groupBox2.Controls.Add(this.labelCircleDisplay);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.labelCircleArea);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textRadius);
            this.groupBox2.Controls.Add(this.textCircleID);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(12, 247);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(742, 245);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Circle";
            // 
            // labelCirclePerimeter
            // 
            this.labelCirclePerimeter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelCirclePerimeter.Location = new System.Drawing.Point(355, 113);
            this.labelCirclePerimeter.Name = "labelCirclePerimeter";
            this.labelCirclePerimeter.Size = new System.Drawing.Size(280, 24);
            this.labelCirclePerimeter.TabIndex = 27;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(219, 117);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 25);
            this.label19.TabIndex = 28;
            this.label19.Text = "Perimeter:";
            // 
            // buttonCircleCalculate
            // 
            this.buttonCircleCalculate.Location = new System.Drawing.Point(330, 169);
            this.buttonCircleCalculate.Name = "buttonCircleCalculate";
            this.buttonCircleCalculate.Size = new System.Drawing.Size(156, 39);
            this.buttonCircleCalculate.TabIndex = 26;
            this.buttonCircleCalculate.Text = "Calculate Area";
            this.buttonCircleCalculate.UseVisualStyleBackColor = true;
            this.buttonCircleCalculate.Click += new System.EventHandler(this.buttonCircleCalculate_Click);
            // 
            // buttonCircleAssignAndDisplay
            // 
            this.buttonCircleAssignAndDisplay.Location = new System.Drawing.Point(68, 166);
            this.buttonCircleAssignAndDisplay.Name = "buttonCircleAssignAndDisplay";
            this.buttonCircleAssignAndDisplay.Size = new System.Drawing.Size(184, 42);
            this.buttonCircleAssignAndDisplay.TabIndex = 25;
            this.buttonCircleAssignAndDisplay.Text = "Assign and Display";
            this.buttonCircleAssignAndDisplay.UseVisualStyleBackColor = true;
            this.buttonCircleAssignAndDisplay.Click += new System.EventHandler(this.buttonCircleAssignAndDisplay_Click);
            // 
            // labelCircleDisplay
            // 
            this.labelCircleDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelCircleDisplay.Location = new System.Drawing.Point(355, 28);
            this.labelCircleDisplay.Name = "labelCircleDisplay";
            this.labelCircleDisplay.Size = new System.Drawing.Size(280, 24);
            this.labelCircleDisplay.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(236, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 25);
            this.label7.TabIndex = 22;
            this.label7.Text = "Display:";
            // 
            // labelCircleArea
            // 
            this.labelCircleArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelCircleArea.Location = new System.Drawing.Point(355, 71);
            this.labelCircleArea.Name = "labelCircleArea";
            this.labelCircleArea.Size = new System.Drawing.Size(280, 24);
            this.labelCircleArea.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(253, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 25);
            this.label9.TabIndex = 24;
            this.label9.Text = "Area:";
            // 
            // textRadius
            // 
            this.textRadius.Location = new System.Drawing.Point(89, 70);
            this.textRadius.Name = "textRadius";
            this.textRadius.Size = new System.Drawing.Size(129, 30);
            this.textRadius.TabIndex = 18;
            this.textRadius.Text = "2.25";
            // 
            // textCircleID
            // 
            this.textCircleID.Location = new System.Drawing.Point(89, 28);
            this.textCircleID.Name = "textCircleID";
            this.textCircleID.Size = new System.Drawing.Size(129, 30);
            this.textCircleID.TabIndex = 15;
            this.textCircleID.Text = "C001";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 25);
            this.label11.TabIndex = 19;
            this.label11.Text = "Radius:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(51, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 25);
            this.label12.TabIndex = 17;
            this.label12.Text = "ID:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelRectPerimeter);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.buttonRectCalculate);
            this.groupBox1.Controls.Add(this.buttonRectAssignAndDisplay);
            this.groupBox1.Controls.Add(this.labelRectDisplay);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.labelRectArea);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textRectHeight);
            this.groupBox1.Controls.Add(this.textRectWidth);
            this.groupBox1.Controls.Add(this.textRectID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(742, 229);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rectangle";
            // 
            // labelRectPerimeter
            // 
            this.labelRectPerimeter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRectPerimeter.Location = new System.Drawing.Point(348, 124);
            this.labelRectPerimeter.Name = "labelRectPerimeter";
            this.labelRectPerimeter.Size = new System.Drawing.Size(280, 24);
            this.labelRectPerimeter.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(236, 126);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 25);
            this.label17.TabIndex = 16;
            this.label17.Text = "Perimeter:";
            // 
            // buttonRectCalculate
            // 
            this.buttonRectCalculate.Location = new System.Drawing.Point(332, 165);
            this.buttonRectCalculate.Name = "buttonRectCalculate";
            this.buttonRectCalculate.Size = new System.Drawing.Size(156, 39);
            this.buttonRectCalculate.TabIndex = 14;
            this.buttonRectCalculate.Text = "Calculate Area";
            this.buttonRectCalculate.UseVisualStyleBackColor = true;
            this.buttonRectCalculate.Click += new System.EventHandler(this.buttonRectCalculate_Click);
            // 
            // buttonRectAssignAndDisplay
            // 
            this.buttonRectAssignAndDisplay.Location = new System.Drawing.Point(70, 162);
            this.buttonRectAssignAndDisplay.Name = "buttonRectAssignAndDisplay";
            this.buttonRectAssignAndDisplay.Size = new System.Drawing.Size(184, 42);
            this.buttonRectAssignAndDisplay.TabIndex = 13;
            this.buttonRectAssignAndDisplay.Text = "Assign and Display";
            this.buttonRectAssignAndDisplay.UseVisualStyleBackColor = true;
            this.buttonRectAssignAndDisplay.Click += new System.EventHandler(this.buttonRectAssignAndDisplay_Click);
            // 
            // labelRectDisplay
            // 
            this.labelRectDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRectDisplay.Location = new System.Drawing.Point(347, 39);
            this.labelRectDisplay.Name = "labelRectDisplay";
            this.labelRectDisplay.Size = new System.Drawing.Size(280, 24);
            this.labelRectDisplay.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Display:";
            // 
            // labelRectArea
            // 
            this.labelRectArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelRectArea.Location = new System.Drawing.Point(347, 83);
            this.labelRectArea.Name = "labelRectArea";
            this.labelRectArea.Size = new System.Drawing.Size(280, 24);
            this.labelRectArea.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 25);
            this.label4.TabIndex = 12;
            this.label4.Text = "Area:";
            // 
            // textRectHeight
            // 
            this.textRectHeight.Location = new System.Drawing.Point(89, 120);
            this.textRectHeight.Name = "textRectHeight";
            this.textRectHeight.Size = new System.Drawing.Size(129, 30);
            this.textRectHeight.TabIndex = 8;
            this.textRectHeight.Text = "4.5";
            // 
            // textRectWidth
            // 
            this.textRectWidth.Location = new System.Drawing.Point(89, 74);
            this.textRectWidth.Name = "textRectWidth";
            this.textRectWidth.Size = new System.Drawing.Size(129, 30);
            this.textRectWidth.TabIndex = 6;
            this.textRectWidth.Text = "3.5";
            // 
            // textRectID
            // 
            this.textRectID.Location = new System.Drawing.Point(89, 32);
            this.textRectID.Name = "textRectID";
            this.textRectID.Size = new System.Drawing.Size(129, 30);
            this.textRectID.TabIndex = 3;
            this.textRectID.Text = "R001";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Height:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Width:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonCalTriArea);
            this.groupBox3.Controls.Add(this.buttonTriAssignNDisplay);
            this.groupBox3.Controls.Add(this.labelTriDisplay);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.labelTriPerimeter);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.labelTriArea);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.textTriHeight);
            this.groupBox3.Controls.Add(this.textTriBase);
            this.groupBox3.Controls.Add(this.textTriID);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Location = new System.Drawing.Point(12, 498);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(742, 229);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Triangle";
            // 
            // buttonCalTriArea
            // 
            this.buttonCalTriArea.Location = new System.Drawing.Point(332, 165);
            this.buttonCalTriArea.Name = "buttonCalTriArea";
            this.buttonCalTriArea.Size = new System.Drawing.Size(156, 39);
            this.buttonCalTriArea.TabIndex = 14;
            this.buttonCalTriArea.Text = "Calculate Area";
            this.buttonCalTriArea.UseVisualStyleBackColor = true;
            this.buttonCalTriArea.Click += new System.EventHandler(this.buttonCalTriArea_Click);
            // 
            // buttonTriAssignNDisplay
            // 
            this.buttonTriAssignNDisplay.Location = new System.Drawing.Point(70, 162);
            this.buttonTriAssignNDisplay.Name = "buttonTriAssignNDisplay";
            this.buttonTriAssignNDisplay.Size = new System.Drawing.Size(184, 42);
            this.buttonTriAssignNDisplay.TabIndex = 13;
            this.buttonTriAssignNDisplay.Text = "Assign and Display";
            this.buttonTriAssignNDisplay.UseVisualStyleBackColor = true;
            this.buttonTriAssignNDisplay.Click += new System.EventHandler(this.buttonTriAssignNDisplay_Click);
            // 
            // labelTriDisplay
            // 
            this.labelTriDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTriDisplay.Location = new System.Drawing.Point(355, 41);
            this.labelTriDisplay.Name = "labelTriDisplay";
            this.labelTriDisplay.Size = new System.Drawing.Size(280, 24);
            this.labelTriDisplay.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(260, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Display:";
            // 
            // labelTriPerimeter
            // 
            this.labelTriPerimeter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTriPerimeter.Location = new System.Drawing.Point(355, 123);
            this.labelTriPerimeter.Name = "labelTriPerimeter";
            this.labelTriPerimeter.Size = new System.Drawing.Size(280, 24);
            this.labelTriPerimeter.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(243, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "Perimeter:";
            // 
            // labelTriArea
            // 
            this.labelTriArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTriArea.Location = new System.Drawing.Point(355, 84);
            this.labelTriArea.Name = "labelTriArea";
            this.labelTriArea.Size = new System.Drawing.Size(280, 24);
            this.labelTriArea.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(277, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 25);
            this.label13.TabIndex = 12;
            this.label13.Text = "Area:";
            // 
            // textTriHeight
            // 
            this.textTriHeight.Location = new System.Drawing.Point(89, 120);
            this.textTriHeight.Name = "textTriHeight";
            this.textTriHeight.Size = new System.Drawing.Size(129, 30);
            this.textTriHeight.TabIndex = 8;
            this.textTriHeight.Text = "3.5";
            // 
            // textTriBase
            // 
            this.textTriBase.Location = new System.Drawing.Point(89, 74);
            this.textTriBase.Name = "textTriBase";
            this.textTriBase.Size = new System.Drawing.Size(129, 30);
            this.textTriBase.TabIndex = 6;
            this.textTriBase.Text = "2.5";
            // 
            // textTriID
            // 
            this.textTriID.Location = new System.Drawing.Point(89, 32);
            this.textTriID.Name = "textTriID";
            this.textTriID.Size = new System.Drawing.Size(129, 30);
            this.textTriID.TabIndex = 3;
            this.textTriID.Text = "T001";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 123);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 25);
            this.label14.TabIndex = 4;
            this.label14.Text = "Height:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(26, 80);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 25);
            this.label15.TabIndex = 7;
            this.label15.Text = "Base:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(50, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 25);
            this.label16.TabIndex = 5;
            this.label16.Text = "ID:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 773);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonCircleCalculate;
        private System.Windows.Forms.Button buttonCircleAssignAndDisplay;
        private System.Windows.Forms.Label labelCircleDisplay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelCircleArea;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textRadius;
        private System.Windows.Forms.TextBox textCircleID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRectCalculate;
        private System.Windows.Forms.Button buttonRectAssignAndDisplay;
        private System.Windows.Forms.Label labelRectDisplay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelRectArea;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textRectHeight;
        private System.Windows.Forms.TextBox textRectWidth;
        private System.Windows.Forms.TextBox textRectID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonCalTriArea;
        private System.Windows.Forms.Button buttonTriAssignNDisplay;
        private System.Windows.Forms.Label labelTriDisplay;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelTriPerimeter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelTriArea;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textTriHeight;
        private System.Windows.Forms.TextBox textTriBase;
        private System.Windows.Forms.TextBox textTriID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelCirclePerimeter;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labelRectPerimeter;
        private System.Windows.Forms.Label label17;
    }
}

