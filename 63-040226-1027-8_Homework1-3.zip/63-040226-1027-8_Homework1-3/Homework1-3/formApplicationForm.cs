﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework1_3
{
    public partial class formApplicationForm : Form
    {
        public formApplicationForm()
        {
            InitializeComponent();
        }

        private void buttonApply_Click(object sender, EventArgs e)
        {
            if (textName.Text == "")
            {
                textName.Focus();

            }
            else if (comboPreferences.SelectedIndex < 0)
            {
                comboPreferences.Focus();
            }
            else
            {
                int selectedIndex = comboPreferences.SelectedIndex;
                Object selectedItem = comboPreferences.SelectedItem;
                MessageBox.Show("Name: " + textName.Text + "\n" +
                                "DOB: " + dateDOB.Value.ToString() + "\n" +
                                "Likes: " + selectedItem.ToString(), "Summary of your appication");
            }
        }

        private void buttonCancle_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        private void CheckIntInput(TextBox src)
        {

            int x;
            if (int.TryParse(textName.Text, out x))
            {
                textName.Text = "";
                textName.Focus();

            }

        }
        private void textName_TextChanged(object sender, EventArgs e)
        {
            CheckIntInput(textName);

        }
    }
}
