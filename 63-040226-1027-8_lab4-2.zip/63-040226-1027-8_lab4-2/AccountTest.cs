﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_2
{
    class AccountTest
    {
            static void Main(string[] args)
            {
                var myAccount = new Account();
                Console.WriteLine($"Initial name is:{myAccount.Name}");

                Console.Write("Enter the name:");
                string theName = Console.ReadLine();
                myAccount.Name = theName;

                Console.WriteLine($"myAccount name is:{myAccount.Name}");
                Console.ReadLine();
            }
        }
    }

