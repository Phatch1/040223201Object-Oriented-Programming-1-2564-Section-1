﻿
namespace Lab2_1
{
    partial class formLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupUserDetails = new System.Windows.Forms.GroupBox();
            this.listCity = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupGender = new System.Windows.Forms.GroupBox();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.groupTutorial = new System.Windows.Forms.GroupBox();
            this.checkPython = new System.Windows.Forms.CheckBox();
            this.checkCSharp = new System.Windows.Forms.CheckBox();
            this.checkASPNET = new System.Windows.Forms.CheckBox();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.groupUserDetails.SuspendLayout();
            this.groupGender.SuspendLayout();
            this.groupTutorial.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupUserDetails
            // 
            this.groupUserDetails.Controls.Add(this.listCity);
            this.groupUserDetails.Controls.Add(this.label3);
            this.groupUserDetails.Controls.Add(this.textAddress);
            this.groupUserDetails.Controls.Add(this.textName);
            this.groupUserDetails.Controls.Add(this.label2);
            this.groupUserDetails.Controls.Add(this.label1);
            this.groupUserDetails.Location = new System.Drawing.Point(68, 62);
            this.groupUserDetails.Name = "groupUserDetails";
            this.groupUserDetails.Size = new System.Drawing.Size(575, 397);
            this.groupUserDetails.TabIndex = 0;
            this.groupUserDetails.TabStop = false;
            this.groupUserDetails.Text = "User Details";
            // 
            // listCity
            // 
            this.listCity.FormattingEnabled = true;
            this.listCity.ItemHeight = 29;
            this.listCity.Items.AddRange(new object[] {
            "Bangkok",
            "Nonthaburi",
            "Nakhon Pathom",
            "Samut Prakan",
            "Samut Songkhram",
            "Samut Sakhon"});
            this.listCity.Location = new System.Drawing.Point(159, 184);
            this.listCity.Name = "listCity";
            this.listCity.Size = new System.Drawing.Size(369, 149);
            this.listCity.TabIndex = 3;
            this.listCity.SelectedIndexChanged += new System.EventHandler(this.listCity_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "City:";
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(159, 106);
            this.textAddress.Name = "textAddress";
            this.textAddress.Size = new System.Drawing.Size(369, 34);
            this.textAddress.TabIndex = 1;
            this.textAddress.TextChanged += new System.EventHandler(this.textAddress_TextChanged);
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(159, 49);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(369, 34);
            this.textName.TabIndex = 1;
            this.textName.TextChanged += new System.EventHandler(this.textName_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 106);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(108, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Address:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 52);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(84, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // groupGender
            // 
            this.groupGender.Controls.Add(this.radioFemale);
            this.groupGender.Controls.Add(this.radioMale);
            this.groupGender.Location = new System.Drawing.Point(682, 62);
            this.groupGender.Name = "groupGender";
            this.groupGender.Size = new System.Drawing.Size(395, 156);
            this.groupGender.TabIndex = 1;
            this.groupGender.TabStop = false;
            this.groupGender.Text = "Gender";
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Location = new System.Drawing.Point(24, 102);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(116, 33);
            this.radioFemale.TabIndex = 0;
            this.radioFemale.TabStop = true;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Location = new System.Drawing.Point(24, 52);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(87, 33);
            this.radioMale.TabIndex = 0;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // groupTutorial
            // 
            this.groupTutorial.Controls.Add(this.checkPython);
            this.groupTutorial.Controls.Add(this.checkCSharp);
            this.groupTutorial.Controls.Add(this.checkASPNET);
            this.groupTutorial.Location = new System.Drawing.Point(682, 246);
            this.groupTutorial.Name = "groupTutorial";
            this.groupTutorial.Size = new System.Drawing.Size(395, 192);
            this.groupTutorial.TabIndex = 2;
            this.groupTutorial.TabStop = false;
            this.groupTutorial.Text = "Tutorial";
            // 
            // checkPython
            // 
            this.checkPython.AutoSize = true;
            this.checkPython.Location = new System.Drawing.Point(38, 130);
            this.checkPython.Name = "checkPython";
            this.checkPython.Size = new System.Drawing.Size(108, 33);
            this.checkPython.TabIndex = 0;
            this.checkPython.Text = "Python";
            this.checkPython.UseVisualStyleBackColor = true;
            // 
            // checkCSharp
            // 
            this.checkCSharp.AutoSize = true;
            this.checkCSharp.Location = new System.Drawing.Point(38, 52);
            this.checkCSharp.Name = "checkCSharp";
            this.checkCSharp.Size = new System.Drawing.Size(65, 33);
            this.checkCSharp.TabIndex = 0;
            this.checkCSharp.Text = "C#";
            this.checkCSharp.UseVisualStyleBackColor = true;
            // 
            // checkASPNET
            // 
            this.checkASPNET.AutoSize = true;
            this.checkASPNET.Location = new System.Drawing.Point(38, 91);
            this.checkASPNET.Name = "checkASPNET";
            this.checkASPNET.Size = new System.Drawing.Size(138, 33);
            this.checkASPNET.TabIndex = 0;
            this.checkASPNET.Text = "ASP.NET";
            this.checkASPNET.UseVisualStyleBackColor = true;
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(145, 482);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(185, 61);
            this.buttonSubmit.TabIndex = 3;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(411, 482);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(185, 61);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            // 
            // formLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1119, 587);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.groupTutorial);
            this.Controls.Add(this.groupGender);
            this.Controls.Add(this.groupUserDetails);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "formLogin";
            this.Text = "Login App";
            this.groupUserDetails.ResumeLayout(false);
            this.groupUserDetails.PerformLayout();
            this.groupGender.ResumeLayout(false);
            this.groupGender.PerformLayout();
            this.groupTutorial.ResumeLayout(false);
            this.groupTutorial.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupUserDetails;
        private System.Windows.Forms.ListBox listCity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupGender;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.GroupBox groupTutorial;
        private System.Windows.Forms.CheckBox checkPython;
        private System.Windows.Forms.CheckBox checkCSharp;
        private System.Windows.Forms.CheckBox checkASPNET;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonExit;
    }
}

