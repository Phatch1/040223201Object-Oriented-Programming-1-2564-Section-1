﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_1
{
    public partial class formLogin : Form
    {
        public formLogin()
        {
            InitializeComponent();
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            string gender;
            if (radioMale.Checked)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            string tutorial = string.Empty;
            if (checkCSharp.Checked)
            {
                tutorial += checkCSharp.Text;
            }
            if (checkASPNET.Checked)
            {
                tutorial += " " + checkASPNET.Text;
            }
            if (checkPython.Checked)
            {
                tutorial += " " + checkPython.Text;
            }
            MessageBox.Show("Your name is " + textName.Text + "\n" +
                            "Your address is " + textAddress.Text + "\n" +
                            "you are " + gender + "\n" +
                            "Your tutorials are: " + tutorial);
        }

        private void textName_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void listCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("You live in " + listCity.SelectedItem + " province");
        }
    }
}
