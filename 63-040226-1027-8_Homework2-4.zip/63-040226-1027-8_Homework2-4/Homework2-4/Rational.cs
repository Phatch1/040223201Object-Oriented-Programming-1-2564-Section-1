﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_4
{
    class Rational
    {
        #region FIELD
        private double _dNumerator;
        private double _dDenominator;
        #endregion

        #region PROPERTY
        protected double Numerator
        {
            get { return _dNumerator; }
            set { _dNumerator = value; }
        }
        protected double Denominator
        {
            get { return _dDenominator; }
            set { _dDenominator = value; }
        }
        #endregion

        #region CONSTRUCTOR
        public Rational()
        {
            _dNumerator = 0;
            _dDenominator = 1;
        }
        public Rational(double a, double b)
        {
            _dNumerator = a;
            _dDenominator = b;
        }
        #endregion
        #region METHOD
        public Rational Add(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = (this._dNumerator * objR._dDenominator + this._dDenominator * objR._dNumerator);
            rational._dDenominator = this._dDenominator * objR._dDenominator;
            return rational;
        }
        public Rational Substract(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = (this._dNumerator * objR._dDenominator) - (this._dDenominator * objR._dNumerator);
            rational._dDenominator = this._dDenominator * objR._dDenominator;
            return rational;
        }
        public Rational Multiply(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = this._dNumerator * objR._dNumerator;
            rational._dDenominator = this._dDenominator * objR._dDenominator;
            return rational;
        }
        public Rational Divide(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = this._dNumerator * objR._dDenominator;
            rational._dDenominator = this._dDenominator * objR._dNumerator;
            return rational;
        }
        protected Rational Reduce()
        {
            for (int i = 2; i < 50; i++)
            {
                if (this._dNumerator % i == 0 && this._dDenominator % i == 0)
                {
                    this._dNumerator = this._dNumerator / i;
                    this.Denominator = this.Denominator / i;
                    Reduce();
                }
            }
            return this;
        }
        public override string ToString()
        {
            return Numerator.ToString() + "/" + Denominator.ToString();
        }
        public static Rational operator +(Rational objL, Rational objR)
        {
            return objL.Add(objR).Reduce();
        }
        public static Rational operator -(Rational objL, Rational objR)
        {
            return objL.Substract(objR).Reduce();
        }
        public static Rational operator /(Rational objL, Rational objR)
        {
            return objL.Divide(objR).Reduce();
        }
        public static Rational operator *(Rational objL, Rational objR)
        {
            return objL.Multiply(objR).Reduce();
        }
        #endregion
    }
}
