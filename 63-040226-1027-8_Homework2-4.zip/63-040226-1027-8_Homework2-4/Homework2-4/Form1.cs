﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework2_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double num1 = Convert.ToDouble(text_a.Text);
            double denom1 = Convert.ToDouble(text_b.Text);
            double num2 = Convert.ToDouble(text_c.Text);
            double denom2 = Convert.ToDouble(text_d.Text);
            Rational fraction1 = new Rational(num1, denom1);
            Rational fraction2 = new Rational(num2, denom2);
            if (radioAdd.Checked)
            {
                labelResult.Text = Convert.ToString(fraction1 + fraction2);
            }
            else if(radioSubtract.Checked)
            {
                labelResult.Text = Convert.ToString(fraction1 - fraction2);
            }
            else if (radioMultiply.Checked)
            {
                labelResult.Text = Convert.ToString(fraction1 * fraction2);
            }
            else if (radioDivide.Checked)
            {
                labelResult.Text = Convert.ToString(fraction1 / fraction2);
            }
        }
    }
}
