﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework1_4
{
    public partial class formBMI : Form
    {
        public formBMI()
        {
            InitializeComponent();
        }
        double BMI(double dHeight, double dWeight)
        {
            double result = dWeight / Math.Pow(dHeight, 2);
            return result;
        }

        private void buttonShowBMI_Click_Click(object sender, EventArgs e)
        {
            int feet_value = Convert.ToInt32(textFeet.Text);
            int inches_value = Convert.ToInt32(textInches.Text);
            int stone_value = Convert.ToInt32(textStone.Text);
            int pound_value = Convert.ToInt32(textPounds.Text);

            double height = (feet_value * 0.3) + (inches_value * 0.025);
            double weight = (stone_value + (pound_value / 14)) * 6.35029318;
            double result = BMI(height, weight);

            MessageBox.Show($"Your BMI is {result.ToString("0.##")}");
        }
    }
}
