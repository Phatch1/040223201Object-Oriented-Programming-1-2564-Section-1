﻿
namespace Homework1_4
{
    partial class formBMI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textInches = new System.Windows.Forms.TextBox();
            this.textFeet = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonShowBMI_Click = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textStone = new System.Windows.Forms.TextBox();
            this.textPounds = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textInches);
            this.groupBox1.Controls.Add(this.textFeet);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(26, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(273, 151);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // textInches
            // 
            this.textInches.Location = new System.Drawing.Point(117, 87);
            this.textInches.Name = "textInches";
            this.textInches.Size = new System.Drawing.Size(100, 34);
            this.textInches.TabIndex = 1;
            // 
            // textFeet
            // 
            this.textFeet.Location = new System.Drawing.Point(117, 27);
            this.textFeet.Name = "textFeet";
            this.textFeet.Size = new System.Drawing.Size(100, 34);
            this.textFeet.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Inches:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Feet:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textPounds);
            this.groupBox2.Controls.Add(this.textStone);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(354, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(323, 151);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Stone:";
            // 
            // buttonShowBMI_Click
            // 
            this.buttonShowBMI_Click.Location = new System.Drawing.Point(159, 217);
            this.buttonShowBMI_Click.Name = "buttonShowBMI_Click";
            this.buttonShowBMI_Click.Size = new System.Drawing.Size(326, 48);
            this.buttonShowBMI_Click.TabIndex = 1;
            this.buttonShowBMI_Click.Text = "Show Body Mass Index";
            this.buttonShowBMI_Click.UseVisualStyleBackColor = true;
            this.buttonShowBMI_Click.Click += new System.EventHandler(this.buttonShowBMI_Click_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "Pounds:";
            // 
            // textStone
            // 
            this.textStone.Location = new System.Drawing.Point(144, 32);
            this.textStone.Name = "textStone";
            this.textStone.Size = new System.Drawing.Size(100, 34);
            this.textStone.TabIndex = 1;
            // 
            // textPounds
            // 
            this.textPounds.Location = new System.Drawing.Point(144, 90);
            this.textPounds.Name = "textPounds";
            this.textPounds.Size = new System.Drawing.Size(100, 34);
            this.textPounds.TabIndex = 1;
            // 
            // formBMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 331);
            this.Controls.Add(this.buttonShowBMI_Click);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "formBMI";
            this.Text = "BMI calculator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textInches;
        private System.Windows.Forms.TextBox textFeet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonShowBMI_Click;
        private System.Windows.Forms.TextBox textPounds;
        private System.Windows.Forms.TextBox textStone;
        private System.Windows.Forms.Label label4;
    }
}

