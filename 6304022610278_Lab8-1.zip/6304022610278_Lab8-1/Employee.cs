﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/////////////////////////////////////////////////////////////////////////////////////
// Subject          : Object Oriented Programming
// Academic Year    : 1/2021
// Topic      	    : Lab8-1
// Module           : Employee Class
// Instructor       : Asst. Prof. Dr.Dome Lohpetch
// Student ID       :
// Student Name     : 
// Lab Date         : 
/////////////////////////////////////////////////////////////////////////////////////

namespace Lab8_1
{
    class Employee
    {
        #region Fields
        private string _sID;
        private string _sName;
        private int _nPosition;
        private double _dSalary;
        #endregion

        #region Constructors
        public Employee()
        {
            _sID = "EMP001";

            _sName = "MR. X";

            _nPosition = 3;

            _dSalary = 15000;
        }

        public Employee(string sID, string sName, int nPosition, double dSalary)
        {
            _sID = sID;
            _sName = sName;
            Position = nPosition;
            Salary = dSalary;
        }
        #endregion

        #region Properties
        public string ID
        {
            get { return _sID; }
            set { _sID = value; }
        }

        public string Name
        {
            get { return _sName; }
            set { _sName = value; }
        }
        public int Position
        {
            get { return _nPosition; }
            set 
            {

                if (value >= 4)
                {
                    throw new ArgumentOutOfRangeException("Position value must be between 0 and 3");

                }
                else
                {
                  _nPosition = value;
                }
            }
        }

        public string PositionName
        {
            get
            {
                if (Position == 0)
                {
                    return "President";
                }
                else if (Position == 1)
                {
                    return "Manager";
                }
                else if (Position == 2)
                {
                    return "Supervisor";
                }
                else if (Position == 3)
                {
                    return "Officer";
                }
                return string.Empty;
            }
        }

        public double Salary
        {
            get { return _dSalary; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("Salary must be greater than or equal to zero");

                }

                _dSalary = value;
            }
        }
        #endregion

        #region Methods

        public override string ToString()
        {
            return _sID + ": " + _sName + "-" + PositionName + " [ " + _dSalary.ToString("#,#.00") + "]";
        }

        #endregion
    }
}

