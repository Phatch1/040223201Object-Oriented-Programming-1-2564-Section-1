﻿
namespace Lab_13_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonFontSize = new System.Windows.Forms.Button();
            this.buttonForeColor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(196, 82);
            this.textBox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(765, 324);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "text";
            // 
            // buttonFontSize
            // 
            this.buttonFontSize.Location = new System.Drawing.Point(196, 443);
            this.buttonFontSize.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.buttonFontSize.Name = "buttonFontSize";
            this.buttonFontSize.Size = new System.Drawing.Size(296, 58);
            this.buttonFontSize.TabIndex = 1;
            this.buttonFontSize.Text = "Font Size";
            this.buttonFontSize.UseVisualStyleBackColor = true;
            this.buttonFontSize.Click += new System.EventHandler(this.buttonFontSize_Click);
            // 
            // buttonForeColor
            // 
            this.buttonForeColor.Location = new System.Drawing.Point(630, 443);
            this.buttonForeColor.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.buttonForeColor.Name = "buttonForeColor";
            this.buttonForeColor.Size = new System.Drawing.Size(331, 58);
            this.buttonForeColor.TabIndex = 1;
            this.buttonForeColor.Text = "Fore Color";
            this.buttonForeColor.UseVisualStyleBackColor = true;
            this.buttonForeColor.Click += new System.EventHandler(this.buttonForeColor_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1197, 587);
            this.Controls.Add(this.buttonForeColor);
            this.Controls.Add(this.buttonFontSize);
            this.Controls.Add(this.textBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonFontSize;
        private System.Windows.Forms.Button buttonForeColor;
    }
}