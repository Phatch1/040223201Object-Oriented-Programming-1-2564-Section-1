﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_13_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonFontSize_Click(object sender, EventArgs e)
        {
            ComboDialog dialong = new ComboDialog();

            string[] items = { "10", "14", "18", "20" };
            dialong.AddItem(items);
            dialong.Description = "กรุณาเลือแกขนาดของฟอนต์";

            if (dialong.ShowDialog() == DialogResult.OK) {
                int size = Convert.ToInt16(dialong.SelectedItem);
                Font f = new Font(textBox1.Font.FontFamily, size);
                    textBox1.Font = f;

                }

        }

        private void buttonForeColor_Click(object sender, EventArgs e)
        {
            ComboDialog dialong = new ComboDialog();
            string[] color = {"Red","Green","Blue","Black" };
            dialong.AddItem(color);
            dialong.Description = "กรุณาเลือกสีฟอนต์";
            if (dialong.ShowDialog()== DialogResult.OK)
            {
                textBox1.ForeColor = Color.FromName(dialong.SelectedItem);
            }


        }
    }
}
