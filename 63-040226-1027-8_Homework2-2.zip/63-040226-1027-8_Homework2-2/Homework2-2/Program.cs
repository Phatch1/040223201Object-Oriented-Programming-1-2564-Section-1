﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            PhotoBook photoBook = new PhotoBook();
            Console.WriteLine("Name:" + photoBook.Name + "  " + "Owner:" + photoBook.Owner + "  " + "Numpages:" + photoBook.Numpage + "  " + "Category:" + photoBook.CategoryName);
            PhotoBook photoBook3 = new PhotoBook("Ayutthaya Trip", "phatchara", 24, 4);
            Console.WriteLine("Name:" + photoBook3.Name + "  " + "Owner:" + photoBook3.Owner + "  " + "Numpages:" + photoBook3.Numpage + "  " + "Category:" + photoBook3.CategoryName);
            Console.WriteLine("Name:" + photoBook3.Name + "  " + "Owner:" + photoBook3.Owner + "  " + "Numpages:" + photoBook3.AddPages(12) + "  " + "Category:" + photoBook3.CategoryName);
            photoBook3.Category = 3;
            Console.WriteLine("Name:" + photoBook3.Name + "  " + "Owner:" + photoBook3.Owner + "  " + "Numpages:" + photoBook3.AddPages(12) + "  " + "Category:" + photoBook3.CategoryName);
            Console.ReadLine();
        }
    }
}
