﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_2
{
    class PhotoBook
    {
        private string _sName;
        private int _nNumpages;
        private string _sOwner;
        public int Category;
        public string Name
        {
            get
            {
                return _sName;
            }
            set
            {
                _sName = value;
            }
        }
        public string Owner
        {
            get
            {
                return _sOwner;
            }
            set
            {
                _sOwner = value;
            }
        }
        public int Numpage
        {
            get
            {
                return _nNumpages;
            }
        }
        public string CategoryName
        {
            get
            {
                if (Category == 1)
                {
                    return "Adventure";
                }
                else if (Category == 2)
                {
                    return "Education";
                }
                else if (Category == 3)
                {
                    return "Entertainment";
                }
                else if (Category == 4)
                {
                    return "Travel";
                }
                return string.Empty;
            }
        }
        public PhotoBook()
        {
            Name = "Album01";
            Owner = "Mr.Photo";
            _nNumpages = 16;
            Category = 1;
        }
        public PhotoBook(int nNumpages)
        {
            _nNumpages = nNumpages;
        }
        public PhotoBook(string sName, string sOwner, int nNumpages, int category)
        {
            Name = sName;
            Owner = sOwner;
            _nNumpages = nNumpages;
            Category = category;
        }
        public int AddPages(int nNumpage)
        {
            return _nNumpages + nNumpage;
        }
    }
}
