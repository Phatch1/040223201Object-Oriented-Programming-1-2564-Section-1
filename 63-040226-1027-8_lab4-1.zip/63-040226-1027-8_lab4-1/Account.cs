﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_1
{
    class Account
    {
        private string name;
        
      
        public void SetName(string accountName)
        {
            name = accountName;
        }

        public string getName()
        {
            return name;
        }
    }
}

