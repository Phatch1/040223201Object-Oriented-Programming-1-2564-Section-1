﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_1
{
    class AccountTest
    {
        static void Main(string[] args)
        {
            var myAccount = new Account();
            Console.WriteLine($"Initial name is:{myAccount.getName()}");

            Console.Write("Enter the name:");
            string theName = Console.ReadLine();
            myAccount.SetName(theName);

            Console.WriteLine($"myAccount name is:{myAccount.getName()}");
            Console.ReadLine();
        }
    }
}

