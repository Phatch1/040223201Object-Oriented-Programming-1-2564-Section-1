﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework2_3
{
    public partial class Form1 : Form
    {
        private Employee _myEmployees = null;

        private void formEmployees_Load(object sender, EventArgs e)
        {
            _myEmployees = new Employee();
            DisplayCurrentEmployee();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void DisplayCurrentEmployee()
        {
            labelEmployee.Text = "ID:" + _myEmployees.ID + "Name:" + _myEmployees.Name + "Salary:" + _myEmployees.Salary+"DOB:"+_myEmployees.DoB.ToShortDateString();
        }

        private void buttonDefault_Click(object sender, EventArgs e)
        {
            _myEmployees.IncreaseSalary();
            labelEmployee.Text = "ID:" + _myEmployees.ID + "Name:" + _myEmployees.Name + "Salary:" + _myEmployees.Salary + "DOB:" + _myEmployees.DoB.ToShortDateString();
        }

        private void buttonAmount_Click(object sender, EventArgs e)
        {
            double amount = Convert.ToDouble(textAmount.Text);
            _myEmployees.IncreaseSalary(amount);
            labelEmployee.Text = "ID:" + _myEmployees.ID + "Name:" + _myEmployees.Name + "Salary:" + _myEmployees.Salary + "DOB:" + _myEmployees.DoB.ToShortDateString();
        }

        private void buttonAssign_Click_1(object sender, EventArgs e)
        {

            double salary = Convert.ToDouble(textSalary.Text);
            _myEmployees = new Employee(textID.Text, textName.Text, salary, textDOB.Text);

        }

        private void buttonDisplay_Click_1(object sender, EventArgs e)
        {

            DisplayCurrentEmployee();

        }


        private void buttonPercent_Click(object sender, EventArgs e)
        {
            float amount = Convert.ToInt32(numericPercent.Value);
            _myEmployees.IncreaseSalary(amount);
            labelEmployee.Text = "ID:" + _myEmployees.ID + "Name:" + _myEmployees.Name + "Salary:" + _myEmployees.Salary + "DOB:" + _myEmployees.DoB.ToShortDateString();
        }
    }
}
