﻿
namespace Homework2_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.buttonAssign = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textDOB = new System.Windows.Forms.TextBox();
            this.textSalary = new System.Windows.Forms.TextBox();
            this.textName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelEmployee = new System.Windows.Forms.Label();
            this.buttonDefault = new System.Windows.Forms.Button();
            this.buttonAmount = new System.Windows.Forms.Button();
            this.buttonPercent = new System.Windows.Forms.Button();
            this.textAmount = new System.Windows.Forms.TextBox();
            this.numericPercent = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericPercent)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.Location = new System.Drawing.Point(551, 274);
            this.buttonDisplay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(188, 36);
            this.buttonDisplay.TabIndex = 28;
            this.buttonDisplay.Text = "Display";
            this.buttonDisplay.UseVisualStyleBackColor = true;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click_1);
            // 
            // buttonAssign
            // 
            this.buttonAssign.Location = new System.Drawing.Point(108, 274);
            this.buttonAssign.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAssign.Name = "buttonAssign";
            this.buttonAssign.Size = new System.Drawing.Size(188, 36);
            this.buttonAssign.TabIndex = 29;
            this.buttonAssign.Text = "Assign";
            this.buttonAssign.UseVisualStyleBackColor = true;
            this.buttonAssign.Click += new System.EventHandler(this.buttonAssign_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textDOB);
            this.groupBox1.Controls.Add(this.textSalary);
            this.groupBox1.Controls.Add(this.textName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textID);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(27, 41);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(376, 198);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Data";
            // 
            // textDOB
            // 
            this.textDOB.Location = new System.Drawing.Point(75, 145);
            this.textDOB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textDOB.Name = "textDOB";
            this.textDOB.Size = new System.Drawing.Size(90, 30);
            this.textDOB.TabIndex = 2;
            this.textDOB.Text = "21/05/2534";
            // 
            // textSalary
            // 
            this.textSalary.Location = new System.Drawing.Point(75, 109);
            this.textSalary.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textSalary.Name = "textSalary";
            this.textSalary.Size = new System.Drawing.Size(81, 30);
            this.textSalary.TabIndex = 2;
            this.textSalary.Text = "15000";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(75, 73);
            this.textName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(293, 30);
            this.textName.TabIndex = 2;
            this.textName.Text = "Mr. Somchai Jaidee";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 148);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "DOB =";
            // 
            // textID
            // 
            this.textID.Location = new System.Drawing.Point(75, 37);
            this.textID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textID.Name = "textID";
            this.textID.Size = new System.Drawing.Size(168, 30);
            this.textID.TabIndex = 2;
            this.textID.Text = "EMP021";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 112);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Salary =";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name =";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID =";
            // 
            // labelEmployee
            // 
            this.labelEmployee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelEmployee.Location = new System.Drawing.Point(430, 41);
            this.labelEmployee.Name = "labelEmployee";
            this.labelEmployee.Size = new System.Drawing.Size(425, 63);
            this.labelEmployee.TabIndex = 27;
            // 
            // buttonDefault
            // 
            this.buttonDefault.Location = new System.Drawing.Point(623, 117);
            this.buttonDefault.Name = "buttonDefault";
            this.buttonDefault.Size = new System.Drawing.Size(210, 36);
            this.buttonDefault.TabIndex = 30;
            this.buttonDefault.Text = "Increase Salary by Default";
            this.buttonDefault.UseVisualStyleBackColor = true;
            this.buttonDefault.Click += new System.EventHandler(this.buttonDefault_Click);
            // 
            // buttonAmount
            // 
            this.buttonAmount.Location = new System.Drawing.Point(623, 159);
            this.buttonAmount.Name = "buttonAmount";
            this.buttonAmount.Size = new System.Drawing.Size(210, 36);
            this.buttonAmount.TabIndex = 30;
            this.buttonAmount.Text = "Increase Salary by Amount";
            this.buttonAmount.UseVisualStyleBackColor = true;
            this.buttonAmount.Click += new System.EventHandler(this.buttonAmount_Click);
            // 
            // buttonPercent
            // 
            this.buttonPercent.Location = new System.Drawing.Point(623, 201);
            this.buttonPercent.Name = "buttonPercent";
            this.buttonPercent.Size = new System.Drawing.Size(210, 36);
            this.buttonPercent.TabIndex = 30;
            this.buttonPercent.Text = "Increase Salary by %";
            this.buttonPercent.UseVisualStyleBackColor = true;
            this.buttonPercent.Click += new System.EventHandler(this.buttonPercent_Click);
            // 
            // textAmount
            // 
            this.textAmount.Location = new System.Drawing.Point(535, 164);
            this.textAmount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textAmount.Name = "textAmount";
            this.textAmount.Size = new System.Drawing.Size(81, 30);
            this.textAmount.TabIndex = 2;
            this.textAmount.Text = "2500.25";
            // 
            // numericPercent
            // 
            this.numericPercent.Location = new System.Drawing.Point(555, 207);
            this.numericPercent.Name = "numericPercent";
            this.numericPercent.Size = new System.Drawing.Size(61, 30);
            this.numericPercent.TabIndex = 31;
            this.numericPercent.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(463, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 25);
            this.label5.TabIndex = 32;
            this.label5.Text = "Amount:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(526, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 25);
            this.label6.TabIndex = 32;
            this.label6.Text = "%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 351);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numericPercent);
            this.Controls.Add(this.textAmount);
            this.Controls.Add(this.buttonPercent);
            this.Controls.Add(this.buttonAmount);
            this.Controls.Add(this.buttonDefault);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.buttonAssign);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.labelEmployee);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericPercent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.Button buttonAssign;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textDOB;
        private System.Windows.Forms.TextBox textSalary;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelEmployee;
        private System.Windows.Forms.Button buttonDefault;
        private System.Windows.Forms.Button buttonAmount;
        private System.Windows.Forms.Button buttonPercent;
        private System.Windows.Forms.TextBox textAmount;
        private System.Windows.Forms.NumericUpDown numericPercent;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

