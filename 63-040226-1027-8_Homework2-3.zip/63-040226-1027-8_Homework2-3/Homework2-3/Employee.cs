﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2_3
{
    class Employee
    {
        #region Fields
        private string _sID;
        private string _sName;
        private double _dSalary;
        public DateTime DoB;
        #endregion

        #region Constructors
        public Employee()
        {

            _sID = "EMP001";
            _sName = "MR. X";
            _dSalary = 5000.0;
        }

        public Employee(int nSalary)
        {
            _sID = "EMP001";
            _sName = "MR. X";
            _dSalary = Convert.ToDouble(nSalary);
        }


        public Employee(double dSalary)
        {
            _sID = "EMP001";
            _sName = "MR. X";
            _dSalary = dSalary;
        }

        public Employee(string sID, string sName, double dSalary,string dob)
        {

            _sID = sID;
            _sName = sName;
            _dSalary = dSalary;
            DoB = DateTime.Parse(dob);
        }
        #endregion

        #region Properties
        public string ID
        {

            get{return _sID;}
            set{_sID = value;}
        }

        public string Name
        {

            get{return _sName;}
            set{_sName = value;}
        }

        public double Salary
        {

            get{return _dSalary;}
            set{_dSalary = value;}
        }
        public int age
        {
            get
            {

                DateTime dateNow = new DateTime(DateTime.Now.Year);
                return dateNow.Year - DoB.Year;
            }
        }
        #endregion

        #region Methods
        public double IncreaseSalary()
        {
            _dSalary = _dSalary*110 / 100;
            return _dSalary;
        }

        public double IncreaseSalary(double dMoney)
        {

             _dSalary = _dSalary + dMoney;
            return _dSalary;
        }

        public double IncreaseSalary(float fPercent)
        {

            _dSalary = _dSalary * (fPercent + 100) / 100;
            return _dSalary;
        }
        #endregion
    }
}
