﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/////////////////////////////////////////////////////////////////////////////////////
// Subject          : Object Oriented Programming
// Academic Year    : 1/2021
// Topic      	    : Lab4-6
// Module           : Main Form - formEmployees
// Instructor       : Assistant Prof. Dr.Dome Lohpetch
// Student ID       :
// Student Name     : 
// Lab Date         : 
/////////////////////////////////////////////////////////////////////////////////////

namespace Lab4_6
{
    /////////////////////////////////////////////////////
    // Lab Detail
    /////////////////////////////////////////////////////
    // 1) Complete the code of Employee class as detail in the lab instruction
    // 2) Complete the code of formEmployees form to make program working completely

    public partial class formEmployees : Form
    {
        private Employee _myEmployees = null;

        private void formEmployees_Load(object sender, EventArgs e)
        {
            _myEmployees = new Employee();
            DisplayCurrentEmployee();
        }

        public formEmployees()
        {
            InitializeComponent();
        }

        private void buttonAssign_Click(object sender, EventArgs e)
        {
            double salary = Convert.ToDouble(textSalary.Text);
            _myEmployees = new Employee(textID.Text, textName.Text, salary);


        }

        private void DisplayCurrentEmployee()
        {
            labelEmployee.Text = "ID:" + _myEmployees.ID + "Name:" + _myEmployees.Name + "Salary:" + _myEmployees.Salary;
            // Display the information of the current employee object (id, name and salary) to labelEmployee label
            // as in the following format "ID: EMP021, Name: Mr. Somchai Jaidee, Salary: 15000"

        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            DisplayCurrentEmployee();
        }
    }
}
