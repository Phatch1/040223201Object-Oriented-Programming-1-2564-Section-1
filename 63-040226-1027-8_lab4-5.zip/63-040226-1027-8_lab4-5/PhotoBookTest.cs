﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_5
{
    class PhotoBookTest
    {
        static void Main(string[] args)
        {
            PhotoBook photoBook = new PhotoBook();

            Console.WriteLine(photoBook.Name +"\n"+ photoBook.Owner+"\n"+photoBook.Numpage);

            PhotoBook photoBook2 = new PhotoBook(3);

            Console.WriteLine(photoBook2.Numpage);

            PhotoBook photoBook3 = new PhotoBook("Ayutthaya Trip", "phatchara",24);

            Console.WriteLine(photoBook3.Name+"\n"+photoBook3.Owner+"\n"+photoBook3.Numpage);

            Console.WriteLine(photoBook3.AddPages(12));

            Console.ReadLine();
        }
    }
}
