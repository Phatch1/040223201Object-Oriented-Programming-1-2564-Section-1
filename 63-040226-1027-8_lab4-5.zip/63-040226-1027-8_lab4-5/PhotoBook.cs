﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_5
{
    class PhotoBook
    {
        
        private string _sName;
        private int _nNumpages;
        private string _sOwner;
        public string Name
        {
            get
            {
                return _sName;
            }
            set
            {
                _sName = value;
            }
        }
        public string Owner
        {
            get
            {
                return _sOwner;
            }
            set
            {
                _sOwner = value;
            }
        }
        public int Numpage
        {
            get
            {
                return _nNumpages;
            }
        }
        public PhotoBook()
        {
            Name = "Album01";
            Owner = "Mr.Photo";
            _nNumpages = 16;
        }
        public PhotoBook(int nNumpages)
        {
            _nNumpages = nNumpages;
        }
        public PhotoBook(string sName, string sOwner, int nNumpages)
        {
            Name = sName;
            Owner = sOwner;
            _nNumpages = nNumpages;
        }
        public int AddPages(int nNumpage)
        {
            return _nNumpages + nNumpage;
        }
}
    }
