﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/////////////////////////////////////////////////////////////////////////////////////
// Subject          : Object Oriented Programming
// Academic Year    : 1/2021
// Topic      	    : Lab4-7
// Module           : Main Form - formRational
// Instructor       : Asst. Prof. Dr.Dome Lohpetch
// Student ID       :
// Student Name     : 
// Lab Date         : 
/////////////////////////////////////////////////////////////////////////////////////

namespace Lab4_7
{
    /////////////////////////////////////////////////////
    // Lab Detail
    /////////////////////////////////////////////////////
    // 1) Create the code of Rational class as detail in the lab instruction
    // 2) Complete the code of formRational form to make program working completely

    public partial class formRational : Form
    {
        public formRational()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            double num1 = Convert.ToDouble(text_a.Text);
            double denom1 = Convert.ToDouble(text_b.Text);
            double num2 = Convert.ToDouble(text_c.Text);
            double denom2 = Convert.ToDouble(text_d.Text);
            Rational fraction1 = new Rational(num1, denom1);
            Rational fraction2 = new Rational(num2, denom2);
            if (radioAdd.Checked)
            {
                labelResult.Text = fraction1.Add(fraction2).ToString();
            }
            else
            {
                labelResult.Text = fraction1.Substract(fraction2).ToString();
            }
        }

        private void formRational_Load(object sender, EventArgs e)
        {

        }
    }
}
