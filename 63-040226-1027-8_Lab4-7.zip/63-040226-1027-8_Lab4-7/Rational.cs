﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4_7
{
    class Rational
    {
        #region FIELD
        private double _dNumerator;
        private double _dDenominator;
        #endregion

        #region PROPERTY
        protected double Numerator
        {
            get { return _dNumerator; }
            set { _dNumerator = value; }
        }
        protected double Denominator
        {
            get { return _dDenominator; }
            set { _dDenominator = value; }
        }
        #endregion

        #region CONSTRUCTOR
        public Rational()
        {
            _dNumerator = 0;
            _dDenominator = 1;
        }
        public Rational(double a, double b)
        {
            _dNumerator = a;
            _dDenominator = b;
        }
        #endregion
        #region METHOD
        public Rational Add(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = (this._dNumerator * objR._dDenominator + this._dDenominator * objR._dNumerator);
            rational._dDenominator = this._dDenominator * objR._dDenominator;
            return rational;
        }
        public Rational Substract(Rational objR)
        {
            Rational rational = new Rational();
            rational._dNumerator = (this._dNumerator * objR._dDenominator) - (this._dDenominator * objR._dNumerator);
            rational._dDenominator = this._dDenominator * objR._dDenominator;
            return rational;
        }

        public override string ToString()
        {
            return Numerator.ToString() + "/" + Denominator.ToString();
        }
        #endregion
    }
}

