﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2 , sum;
            Console.Write("Enter first integer: ");
            num1 = int.Parse(Console.ReadLine());

            Console.Write("Enter second integer: ");
            num2 = int.Parse(Console.ReadLine());

            sum = num1 + num2;
            Console.WriteLine($"SUM IS {sum}");
            Console.ReadLine();


        }
    }
}
