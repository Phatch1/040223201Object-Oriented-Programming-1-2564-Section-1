﻿
namespace Lab10_6
{
    partial class formArea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelArea = new System.Windows.Forms.Label();
            this.labelDisplay = new System.Windows.Forms.Label();
            this.buttonCalArea = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textHeight = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textWidth = new System.Windows.Forms.TextBox();
            this.buttonAssignAndDisplay = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelArea
            // 
            this.labelArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelArea.Location = new System.Drawing.Point(616, 131);
            this.labelArea.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.labelArea.Name = "labelArea";
            this.labelArea.Size = new System.Drawing.Size(418, 49);
            this.labelArea.TabIndex = 25;
            // 
            // labelDisplay
            // 
            this.labelDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelDisplay.Location = new System.Drawing.Point(616, 67);
            this.labelDisplay.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.labelDisplay.Name = "labelDisplay";
            this.labelDisplay.Size = new System.Drawing.Size(418, 40);
            this.labelDisplay.TabIndex = 24;
            // 
            // buttonCalArea
            // 
            this.buttonCalArea.Location = new System.Drawing.Point(575, 307);
            this.buttonCalArea.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.buttonCalArea.Name = "buttonCalArea";
            this.buttonCalArea.Size = new System.Drawing.Size(433, 60);
            this.buttonCalArea.TabIndex = 23;
            this.buttonCalArea.Text = "Calculate Area";
            this.buttonCalArea.UseVisualStyleBackColor = true;
            this.buttonCalArea.Click += new System.EventHandler(this.buttonCalArea_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(519, 151);
            this.label4.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 29);
            this.label4.TabIndex = 22;
            this.label4.Text = "Area:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(490, 78);
            this.label5.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 29);
            this.label5.TabIndex = 21;
            this.label5.Text = "Display:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 196);
            this.label3.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 29);
            this.label3.TabIndex = 20;
            this.label3.Text = "Height:";
            // 
            // textHeight
            // 
            this.textHeight.Location = new System.Drawing.Point(160, 193);
            this.textHeight.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.textHeight.Name = "textHeight";
            this.textHeight.Size = new System.Drawing.Size(218, 34);
            this.textHeight.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 136);
            this.label2.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 29);
            this.label2.TabIndex = 18;
            this.label2.Text = "Width:";
            // 
            // textWidth
            // 
            this.textWidth.Location = new System.Drawing.Point(160, 133);
            this.textWidth.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.textWidth.Name = "textWidth";
            this.textWidth.Size = new System.Drawing.Size(218, 34);
            this.textWidth.TabIndex = 17;
            // 
            // buttonAssignAndDisplay
            // 
            this.buttonAssignAndDisplay.Location = new System.Drawing.Point(66, 307);
            this.buttonAssignAndDisplay.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.buttonAssignAndDisplay.Name = "buttonAssignAndDisplay";
            this.buttonAssignAndDisplay.Size = new System.Drawing.Size(373, 60);
            this.buttonAssignAndDisplay.TabIndex = 16;
            this.buttonAssignAndDisplay.Text = "Assign And Display";
            this.buttonAssignAndDisplay.UseVisualStyleBackColor = true;
            this.buttonAssignAndDisplay.Click += new System.EventHandler(this.buttonAssignAndDisplay_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 29);
            this.label1.TabIndex = 15;
            this.label1.Text = "ID:";
            // 
            // textID
            // 
            this.textID.Location = new System.Drawing.Point(160, 73);
            this.textID.Margin = new System.Windows.Forms.Padding(14, 13, 14, 13);
            this.textID.Name = "textID";
            this.textID.Size = new System.Drawing.Size(218, 34);
            this.textID.TabIndex = 14;
            // 
            // formArea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 450);
            this.Controls.Add(this.labelArea);
            this.Controls.Add(this.labelDisplay);
            this.Controls.Add(this.buttonCalArea);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textHeight);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textWidth);
            this.Controls.Add(this.buttonAssignAndDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textID);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "formArea";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelArea;
        private System.Windows.Forms.Label labelDisplay;
        private System.Windows.Forms.Button buttonCalArea;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textHeight;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textWidth;
        private System.Windows.Forms.Button buttonAssignAndDisplay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textID;
    }
}

