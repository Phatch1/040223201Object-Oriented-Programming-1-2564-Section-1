﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab10_6
{
    public partial class formArea : Form
    {
            private Rectangle _MyRectangle = new Rectangle();
            public formArea()
            {
                InitializeComponent();

            }

        private void buttonAssignAndDisplay_Click(object sender, EventArgs e)
        {
            double dwidth;
            double dhiegt;

            if (double.TryParse(textWidth.Text, out dwidth))
            {
                _MyRectangle.Width = dwidth;

            }
            if (double.TryParse(textHeight.Text, out dhiegt))
            {
                _MyRectangle.Height = dhiegt;
            }
            _MyRectangle.ID = textID.Text;
            labelDisplay.Text = _MyRectangle.ToString();
        }

        private void buttonCalArea_Click(object sender, EventArgs e)
        {
            labelArea.Text = _MyRectangle.Area().ToString();
        }
    }
}
