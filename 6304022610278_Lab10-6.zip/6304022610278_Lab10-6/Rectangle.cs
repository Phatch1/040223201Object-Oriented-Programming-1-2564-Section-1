﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_6
{
    class Rectangle
    {

        private string _SID;
        private string _SName;
        private double _dWidth;
        private double _dHeight;


        public string ID
        {
            set { _SID = value; }
            get { return _SID; }
        }
        public string Name
        {
            get { return _SName; }
        }
        public double Width
        {
            set { _dWidth = value; }
            get { return _dWidth; }
        }
        public double Height
        {
            set { _dHeight = value; }
            get { return _dHeight; }
        }
        public double Area()
        {
            return _dWidth * _dHeight;
        }
        public Rectangle()
        {
            _SID = "R001";
            _SName = "My Rectangle";
            _dWidth = 4.5;
            _dHeight = 4.5;
        }
        public Rectangle(string SID, string SName, double dWidth, double dHeight)
        {
            _SID = SID;
            _SName = SName;
            _dWidth = dWidth;
            _dHeight = dHeight;
        }
        public override string ToString()
        {
            return ID + "(" + Name + ")" + "<" + _dWidth.ToString("0.00") + "," + Height.ToString("0.00") + ">";
        }
    }
}
