﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_3
{
    class AccountTest
    {
        static void Main()
        {
            Account account1 = new Account("Jene Green");
            Account account2 = new Account("John Blue");

            Console.WriteLine($"account1 name is: {account1.Name}");
            Console.WriteLine($"account2 name is: {account2.Name}");
            Console.ReadLine();

        }
    }
}
