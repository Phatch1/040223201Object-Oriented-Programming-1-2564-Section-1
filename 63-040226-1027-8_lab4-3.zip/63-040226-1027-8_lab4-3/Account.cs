﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_3
{
    class Account
    {
        public string Name { get; set; }

        public Account(string accountName)
        {
            Name = accountName;
        }
    }
}

