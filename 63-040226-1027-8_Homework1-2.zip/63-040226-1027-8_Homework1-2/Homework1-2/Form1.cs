﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework1_2
{
    public partial class formApplication : Form
    {
        public formApplication()
        {
            InitializeComponent();
        }
        private void buttonApply_Click(object sender, EventArgs e)
        {
            if (textName.Text == "")
            {
                MessageBox.Show("You must fill in a first name!");
                textName.Focus();
            }
            else if (textLastName.Text == "")
            {
                MessageBox.Show("You must fill in a last name!");
                textLastName.Focus();
            }
            else
            {
                int nAge;
                int nPage;
                try
                {
                    nAge = Convert.ToInt32(textAge.Text);

                }

                catch
                {
                    MessageBox.Show("This isn't a valid age!");
                    textAge.Focus();
                    return;
                }
                try
                {
                    nPage = Convert.ToInt32(textPartnerAge.Text);
                }
                catch
                {
                    MessageBox.Show("This isn't a valid age!");
                    textPartnerAge.Focus();
                    return;
                }
                if (nAge < 18 || nAge > 100)
                {

                    MessageBox.Show("Your must's age must be between 18 and 100!");
                    textAge.Focus();
                    return;
                }
                else if (comboGender.Text.Length == 0)
                {
                    MessageBox.Show("You must fill in your gender!");
                    comboGender.Focus();
                }
                else if (nPage < 18 || nPage > 100)
                {
                    MessageBox.Show("Your partner's age must be between 18 and 100!");
                    textPartnerAge.Focus();
                    return;
                }
                else if (comboPartnerGender.Text.Length == 0)
                {
                    MessageBox.Show("You must fill in your  partner's gender!");
                    comboPartnerGender.Focus();
                }
                else
                {
                    MessageBox.Show("Welcome, " + textName.Text + " " + textLastName.Text + " (" + nAge + "), " + comboGender.Text.ToLower() + " seeking " + comboPartnerGender.Text.ToLower() + " (" + nPage + ")", "Welcome");
                }

            }
        }

        private void buttonCancle_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
